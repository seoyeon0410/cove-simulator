# 웹 모션(motions/*.csv)을 재생하는 씬. cove_scenes.py 에 합치거나 이름만 옮겨 쓰세요.
# 재생 확인용: python3 cove_cmd.py web_rest
WEB_SCENES = {
    "web_rest": [{"motion": "web_rest"}],   # 시나리오1 휴식
    "web_tickle": [{"motion": "web_tickle"}],   # 시나리오2 간지럽히기
    "web_snack": [{"motion": "web_snack"}],   # 시나리오3 간식주기
    "web_greet": [{"motion": "web_greet"}],   # 시나리오4 인사
    "web_expressions": [{"motion": "web_expressions"}],   # 표정 모음
}
